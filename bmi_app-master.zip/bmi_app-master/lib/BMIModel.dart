class BMIModel{
  double bmi;
  bool isNormal;

  String comments;

  BMIModel({this.bmi, this.isNormal, this.comments});
}